<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G-PASSPORT</title>
    <!-- Load CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stylelogin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admindashboard.css')); ?>">
    <!--    <link rel="stylesheet" href="css/style.css">-->
    <!-- Load javascript -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\testing\custom-login-register-update\resources\views/includes/head.blade.php ENDPATH**/ ?>