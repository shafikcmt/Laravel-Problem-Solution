
<?php $__env->startSection('content'); ?>
    <div id="contentpart">
        <div class="container">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4 mt-3 shadow p-4 mb-4 bg-white rounded h-100 ">
                    <div class="card card-main">
                        <div class="card-header">
                            <h3 class="text-center pt-3 pb-3 text-uppercase">Admin Login</h3>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('login-admin')); ?>" method="POST">
                            <?php if(Session::has('success')): ?>
                            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                            <?php endif; ?>
                            <?php if(Session::has('fail')): ?>
                            <div class="alert alert-danger"><?php echo e(Session::get('fail')); ?></div>
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                                <div class="form-floating mb-3 mt-3">
                                    <input type="text" class="form-control shadow" id="roll" value="<?php echo e(old('roll')); ?>" placeholder="Enter roll" name="username">
                                    <label class="text-uppercase" for="roll">Username</label>
                                    <span class="text-danger"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                                <div class="form-floating mb-3 mt-3">
                                    <input type="password" class="form-control shadow" id="pwd" placeholder="Enter password" name="password">
                                    <label class="text-uppercase" for="password">Password</label>
                                    <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                                <div class="form-bottom mt-5">
                                    <button  name="login" type="submit" class="btn btn-primary mt-3">Login</button>
                                    <span style="color:red;">Forgot password</span>

                                </div>



                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testing\custom-login-register-update\resources\views/auth/admin/admin_login.blade.php ENDPATH**/ ?>