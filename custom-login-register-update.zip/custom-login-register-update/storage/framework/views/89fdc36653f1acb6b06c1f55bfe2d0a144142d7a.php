<!doctype html>
<html>
<head>
   <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
   <header>
       <?php echo $__env->make('includes.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </header>
   
   <div id="main">
           <?php echo $__env->yieldContent('content'); ?>
   </div>
   <footer>
       <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel Problem Solution\custom-login-register-update\resources\views/layouts/adminmaster.blade.php ENDPATH**/ ?>