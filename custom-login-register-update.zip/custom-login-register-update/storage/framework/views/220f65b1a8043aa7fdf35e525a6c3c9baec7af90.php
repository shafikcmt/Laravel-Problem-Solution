
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content p-3">
    <div class="container">
    <div class="row">
                    <div class="col-md-12">
                        <h3 class="h3 p-2 mt-0 text-white" style="background-color: #F76A07;">
                            Personal Details
                        </h3>
                        <table class="table table-striped table-hover table-bordered text-center">
                            <tr>
                                <td rowspan="5" valign="middle">Photo</td>
                                <td>Name</td>
                                <td>ANISHA UPPAL</td>
                            </tr>
                            <tr>
                                <td>Roll Number</td>
                                <td>4914112</td>
                            </tr>
                            <tr>
                                <td>College</td>
                                <td>GGI</td>
                            </tr>
                            <tr>
                                <td>Branch</td>
                                <td>CSE</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Gender</td>
                                <td>:</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Date of Birth</td>
                                <td>:</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Blood Group</td>
                                <td>:</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Nationality</td>
                                <td>:</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Mother Tongue</td>
                                <td>:</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Mobile No.</td>
                                <td>:</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td>:</td>
                                <td></td>
                            </tr>
                           
                            

                        </table>
                    </div>
                </div>
    </div>

</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testing\custom-login-register-update\resources\views//student_personal.blade.php ENDPATH**/ ?>