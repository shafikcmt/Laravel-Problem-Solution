
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-content p-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="h3 p-2 mt-0 text-white" style="background-color: #F76A07;">
                            Technical Skills
                        </h3>

                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-first">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-second">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-third">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-four">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-first">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-second">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-third">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="work-item">
                            <div class="card bg-four">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        0
                                    </h4>
                                    <p class="card-text">
                                        Workshops
                                    </p>
                                    <a href="#" class="card-link">More Info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel Problem Solution\custom-login-register-update\resources\views//technical_work.blade.php ENDPATH**/ ?>