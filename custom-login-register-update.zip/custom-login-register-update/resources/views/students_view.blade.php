<!-- @extends('layouts.adminmaster')
    @section('content') -->
    <!-- <div class="container">
        
        <!-- <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <!-- <div class="card">
                    <div class="card-header">
                        <h3 class="float-start">Wellcome to Dashboard</h3>
                        <a href="/admin-logout" class="float-end btn btn-primary">Logout</a>
                    </div>
                    <div class="card-body">
                       <!-- <table class="table tble-striped table-bordered">
                           <thead>
                               <tr>
                                   <th>Roll</th>
                                   <th>Phone</th>
                                   <th>Action</th>
                               </tr>
                           </thead>
                           <tbody>
                               @foreach($students as $stu)
                               <tr>
                                   <td>{{$stu->roll}}</td>
                                   <td>{{$stu->phone}}</td>
                                   <td>
                                       <a href="#" class="btn btn-primary">view</a>
                                       <a href="#" class="btn btn-primary">Edit</a>
                                   </td>
                               </tr>
                               @endforeach
                           </tbody>
                       </table> 
                    </div>
                    <div class="card-footer">
                        <h3>Geeta Technical HUB</h3>
                    </div>
                </div> 
            </div>
        </div> 
    </div> -->
    <!-- @include('includes.adminsidebar') -->
        <div class="main-content p-3">
            <h3>Welcome Students</h3>
        </div>
    </section>
    <!-- @stop -->