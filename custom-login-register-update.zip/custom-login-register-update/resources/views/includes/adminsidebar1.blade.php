<section id="main-section">
    <div class="left-sidebar">
            <div class="wrapper">
                <div class="sidebar">
                    <ul>
                        <li><a href="/admin-dashboard"><i class="fas fa-home"></i>Dashboard</a></li>
                        <li><a href="#"><i class="fas fa-users"></i>Team</a></li>
                        <li class="notification1"><a href="#"><i class="fas fa-calendar-week"></i>Calender</a></li>
                        <li class="notification2"><a href="#"><i class="far fa-envelope"></i>Documents</a></li>
                        <li class="notification3"><a href="/add-admin"><i class="fas fa-users"></i>Add Admin</a></li>
                        </li>
                        <li><a href="#"><i class="fas fa-signal"></i>Reports</a></li>
                    </ul>
                
                
                </div>
        </div>
    </div>