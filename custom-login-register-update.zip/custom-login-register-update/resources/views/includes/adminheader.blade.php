<div id="headerpart">
        <div class="container">
            <div class="container-fluid">
                <div class="well well-sm">
                    <div class="row pt-2">
                        <div class="col-md-4">
                            <!-- <div class="first-title">
                                <span>HAVE ANY QUESTIONS?</span>
                            </div> -->
                        </div>
                        <div class="col-md-4">
                            <!-- <div class="second-title">
                                <span>ghub@geeta.edu.in</span>
                            </div> -->

                        </div>
                        <div class="col-md-4">
                            <nav class=" navbar-expand-md navbar-dark">
                                <ul class="nav navbar-nav justify-content-end">
                                <li class="nav-item"><a class="" href="/admin-logout"><i style="font-size:30px;padding-top:10px;" class="fas fa-user"></i></a></li> 
                                </ul>
                            </nav>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- <div id="second-header" class="bg-info">
        <div class="container ">
            <div class="row">
                <div class="col-md-6">
                    <div class="logo">
                        <a href="/admin-dashboard">
                        <img src="images/gsplogo.jpg" class="img-responsive" alt="">
                        </a>
                       
                    </div>
                </div>
                <div class="col-md-6">
                    <nav class=" navbar-expand-md navbar-dark">
                        <ul class="nav navbar-nav justify-content-end">
                            <li class="nav-item"><a class="btn btn-success" href="">Add Admin</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div> -->
    </div>