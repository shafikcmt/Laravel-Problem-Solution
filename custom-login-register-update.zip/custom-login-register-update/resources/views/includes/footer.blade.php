<div id="footerpart">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="footer-logo">
                        <a href="/">
                       <h3 class="pt-4">Geeta Technical Hub</h3>
                        </a>
                      
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="copy-right pt-3">
                        <p>Copyright &copy;2022 All rights reserved <br>
                            Made with &hearts; by <a href="/">TechnicalHub</a></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="footer-icon pt-3 justify-content-end">
                    <a target="_blank" href="https://www.youtube.com/channel/UCohPL3_a3SAuX19V24rk_4w"><i class="fa-brands fa-youtube"></i></a> 
                       <a target="_blank" href="https://www.instagram.com/gtechnicalhub/"><i class="fa-brands fa-instagram-square"></i></a> 
                        <a target="_blank" href="https://www.facebook.com/gtechnicalhub"><i class="fa-brands fa-facebook-square"></i></a>
                        <a target="_blank" href="https://twitter.com/gtechnicalhub"><i class="fa-brands fa-twitter"></i></a>
                        <a target="_blank" href="https://www.linkedin.com/company/gtechnicalhub/"><i class="fa-brands fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

